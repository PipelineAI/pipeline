# -*- coding: utf-8 -*-

from pio import main
main()
